package br.com.projeto.pessoa;

import java.util.ArrayList;
import java.util.List;

public class Questao6Teste {
    public static void main(String[] args) {
        // Criação de uma lista de pessoas
        List<Questao6> listaDePessoas = new ArrayList<>();

        // Criando objetos Questao6
        Questao6 pessoa1 = new Questao6("Maria Oliveira", "987654321", 25);
        Questao6 pessoa2 = new Questao6("João Silva", "123456789", 30);
        Questao6 pessoa3 = new Questao6("Ana Paula", "456789123", 28);

        // Adicionando pessoas na lista
        listaDePessoas.add(pessoa1);
        listaDePessoas.add(pessoa2);
        listaDePessoas.add(pessoa3);

        // Ordenando a lista em ordem crescente
        System.out.println("Lista em Ordem Crescente (por idade):");
        Questao6.ordenarLista(listaDePessoas, true);
        for (Questao6 pessoa : listaDePessoas) {
            pessoa.exibirInfo();
            System.out.println();
        }

        // Ordenando a lista em ordem decrescente
        System.out.println("Lista em Ordem Decrescente (por idade):");
        Questao6.ordenarLista(listaDePessoas, false);
        for (Questao6 pessoa : listaDePessoas) {
            pessoa.exibirInfo();
            System.out.println();
        }
    }
}
