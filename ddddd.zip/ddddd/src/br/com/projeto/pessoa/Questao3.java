package br.com.projeto.pessoa;

import java.util.List;

public class Questao3 {
    private String nome;
    private String documento;
    private int idade;

    // Construtor
    public Questao3(String nome, String documento, int idade) {
        this.nome = nome;
        this.documento = documento;
        this.idade = idade;
    }

    // Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    // Método para exibir as informações da pessoa
    public void exibirInfo() {
        System.out.println("Nome: " + nome);
        System.out.println("Documento: " + documento);
        System.out.println("Idade: " + idade);
    }

    // Método para adicionar uma pessoa na lista e retornar a lista preenchida
    public static List<Questao3> adicionarPessoaNaLista(List<Questao3> lista, Questao3 novaPessoa) {
        lista.add(novaPessoa);
        return lista;
    }
}
