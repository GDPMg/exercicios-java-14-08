package br.com.projeto.pessoa;

import java.util.ArrayList;
import java.util.List;

public class Questao3Teste {
    public static void main(String[] args) {
        // Criação de uma lista de pessoas
        List<Questao3> listaDePessoas = new ArrayList<>();

        // Criando objetos Questao3
        Questao3 pessoa1 = new Questao3("Maria Oliveira", "987654321", 25);
        Questao3 pessoa2 = new Questao3("João Silva", "123456789", 30);

        // Adicionando pessoas na lista
        listaDePessoas = Questao3.adicionarPessoaNaLista(listaDePessoas, pessoa1);
        listaDePessoas = Questao3.adicionarPessoaNaLista(listaDePessoas, pessoa2);

        // Exibindo as informações de todas as pessoas na lista
        System.out.println("Lista de Pessoas:");
        for (Questao3 pessoa : listaDePessoas) {
            pessoa.exibirInfo();
            System.out.println();
        }
    }
}
