package br.com.projeto.pessoa;

import java.util.HashMap;
import java.util.Map;

public class Questao5Teste {
    public static void main(String[] args) {
        // Criação de um mapa para armazenar as pessoas
        Map<String, Questao5> mapaDePessoas = new HashMap<>();

        // Criando um objeto Questao5
        Questao5 pessoa = new Questao5("Ana Paula", "456789123", 32);

        // Adicionando a pessoa no mapa
        mapaDePessoas = Questao5.adicionarPessoaNoMapa(mapaDePessoas, pessoa);

        // Obtendo a pessoa do mapa pelo documento
        Questao5 pessoaObtida = Questao5.obterPessoaDoMapa(mapaDePessoas, "456789123");

        // Exibindo as informações da pessoa obtida
        System.out.println("Dados da pessoa obtida do mapa:");
        pessoaObtida.exibirInfo();
    }
}
