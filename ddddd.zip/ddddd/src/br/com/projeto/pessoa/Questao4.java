package br.com.projeto.pessoa;

import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Objects;

public class Questao4 {
    private String nome;
    private String documento;
    private int idade;

    // Construtor
    public Questao4(String nome, String documento, int idade) {
        this.nome = nome;
        this.documento = documento;
        this.idade = idade;
    }

    // Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    // Método para exibir as informações da pessoa
    public void exibirInfo() {
        System.out.println("Nome: " + nome);
        System.out.println("Documento: " + documento);
        System.out.println("Idade: " + idade);
    }

    // Sobrescrevendo equals e hashCode para comparar objetos Questao4
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Questao4 questao4 = (Questao4) o;
        return documento.equals(questao4.documento);
    }

    @Override
    public int hashCode() {
        return Objects.hash(documento);
    }

    // Método para adicionar uma pessoa na lista e retornar a lista preenchida
    public static List<Questao4> adicionarPessoaNaLista(List<Questao4> lista, Questao4 novaPessoa) {
        lista.add(novaPessoa);
        return lista;
    }

    // Método para remover duplicados de uma lista de pessoas
    public static List<Questao4> removerDuplicados(List<Questao4> lista) {
        Set<Questao4> set = new HashSet<>(lista);
        return new ArrayList<>(set);
    }
}
