package br.com.projeto.pessoa;

import java.util.ArrayList;
import java.util.List;

public class Questao2Teste {
    public static void main(String[] args) {
        // Criação de uma lista de pessoas
        List<Questao1> listaDePessoas = new ArrayList<>();

        // Criando objetos Questao1
        Questao1 pessoa1 = new Questao1("Maria Oliveira", "987654321", 25);
        Questao1 pessoa2 = new Questao1("João Silva", "123456789", 30);

        // Adicionando pessoas na lista
        listaDePessoas = Questao1.adicionarPessoaNaLista(listaDePessoas, pessoa1);
        listaDePessoas = Questao1.adicionarPessoaNaLista(listaDePessoas, pessoa2);

        // Exibindo as informações de todas as pessoas na lista
        System.out.println("Lista de Pessoas:");
        for (Questao1 pessoa : listaDePessoas) {
            pessoa.exibirInfo();
            System.out.println();
        }
    }
}