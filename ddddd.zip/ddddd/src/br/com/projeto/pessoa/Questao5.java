package br.com.projeto.pessoa;

import java.util.Map;

public class Questao5 {
    private String nome;
    private String documento;
    private int idade;

    // Construtor
    public Questao5(String nome, String documento, int idade) {
        this.nome = nome;
        this.documento = documento;
        this.idade = idade;
    }

    // Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    // Método para exibir as informações da pessoa
    public void exibirInfo() {
        System.out.println("Nome: " + nome);
        System.out.println("Documento: " + documento);
        System.out.println("Idade: " + idade);
    }

    // Método para adicionar uma pessoa no mapa usando o documento como chave
    public static Map<String, Questao5> adicionarPessoaNoMapa(Map<String, Questao5> mapa, Questao5 pessoa) {
        mapa.put(pessoa.getDocumento(), pessoa);
        return mapa;
    }

    // Método para obter uma pessoa do mapa pelo documento
    public static Questao5 obterPessoaDoMapa(Map<String, Questao5> mapa, String documento) {
        return mapa.get(documento);
    }
}
