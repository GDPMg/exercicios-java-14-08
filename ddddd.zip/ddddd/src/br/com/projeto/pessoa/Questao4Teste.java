package br.com.projeto.pessoa;

import java.util.ArrayList;
import java.util.List;

public class Questao4Teste {
    public static void main(String[] args) {
        // Criação de uma lista de pessoas
        List<Questao4> listaDePessoas = new ArrayList<>();

        // Criando objetos Questao4
        Questao4 pessoa1 = new Questao4("Maria Oliveira", "987654321", 25);
        Questao4 pessoa2 = new Questao4("João Silva", "123456789", 30);
        Questao4 pessoa3 = new Questao4("Maria Oliveira", "987654321", 25); // Duplicada

        // Adicionando pessoas na lista
        listaDePessoas = Questao4.adicionarPessoaNaLista(listaDePessoas, pessoa1);
        listaDePessoas = Questao4.adicionarPessoaNaLista(listaDePessoas, pessoa2);
        listaDePessoas = Questao4.adicionarPessoaNaLista(listaDePessoas, pessoa3); // Duplicada

        // Exibindo a lista original com duplicatas
        System.out.println("Lista Original:");
        for (Questao4 pessoa : listaDePessoas) {
            pessoa.exibirInfo();
            System.out.println();
        }

        // Removendo duplicados
        listaDePessoas = Questao4.removerDuplicados(listaDePessoas);

        // Exibindo a lista após remoção de duplicatas
        System.out.println("Lista Sem Duplicatas:");
        for (Questao4 pessoa : listaDePessoas) {
            pessoa.exibirInfo();
            System.out.println();
        }
    }
}
